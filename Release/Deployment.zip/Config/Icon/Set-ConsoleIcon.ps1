﻿param( 
    [string] $iconFile 
) 
 
$WM_SETICON = 0x80 
$ICON_SMALL = 0 
 
function Main 
{ 
    [System.Reflection.Assembly ]::LoadWithPartialName("System.Drawing") | out-null 
    if ([System.IO.File]::Exists($iconFile) -eq $TRUE) 
    { 
        $icon = new-object System.Drawing.Icon($iconFile)  
 
        if ($icon -ne $null) 
        { 
            $consoleHandle = GetConsoleWindow 
            SendMessage $consoleHandle $WM_SETICON $ICON_SMALL $icon.Handle | out-null 
        } 
    } 
    else  
    { 
        Write-Host "Icon file not found" 
    } 
} 
 
function Invoke-Win32([string] $dllName, [Type] $returnType,  
   [string] $methodName, [Type[]] $parameterTypes, [Object[]] $parameters)  
{ 
   $domain = [AppDomain]::CurrentDomain 
   $name = New-Object Reflection.AssemblyName 'PInvokeAssembly' 
   $assembly = $domain.DefineDynamicAssembly($name, 'Run')  
   $module = $assembly.DefineDynamicModule('PInvokeModule') 
   $type = $module.DefineType('PInvokeType', "Public,BeforeFieldInit") 
 
   $inputParameters = @() 
   $refParameters = @() 
   
   for($counter = 1; $counter -le $parameterTypes.Length; $counter++)  
   { 
      if($parameterTypes[$counter - 1] -eq [Ref]) 
      {  
         $refParameters += $counter 
         $parameterTypes[$counter - 1] =  
            $parameters[$counter - 1].Value.GetType().MakeByRefType() 
         $inputParameters += $parameters[$counter - 1].Value 
      } 
      else 
      { 
         $inputParameters += $parameters[$counter - 1] 
      } 
   } 
 
   $method = $type.DefineMethod($methodName, 'Public,HideBySig,Static,PinvokeImpl',  
      $returnType, $parameterTypes)  
   foreach($refParameter in $refParameters) 
   { 
      $method.DefineParameter($refParameter, "Out", $null) 
   } 
 
   $ctor = [Runtime.InteropServices.DllImportAttribute ].GetConstructor([string]) 
   $attr = New-Object Reflection.Emit.CustomAttributeBuilder $ctor, $dllName 
   $method.SetCustomAttribute($attr) 
   $realType = $type.CreateType()  
   $realType.InvokeMember($methodName, 'Public,Static,InvokeMethod', $null, $null,  
      $inputParameters)  
   foreach($refParameter in $refParameters) 
   { 
      $parameters[$refParameter - 1].Value = $inputParameters[$refParameter - 1] 
   } 
} 
 
function SendMessage([IntPtr] $hWnd, [Int32] $message, [Int32] $wParam, [Int32] $lParam)  
{ 
    $parameterTypes = [IntPtr], [Int32], [Int32], [Int32] 
    $parameters = $hWnd, $message, $wParam, $lParam 
 
    Invoke-Win32 "user32.dll" ([Int32]) "SendMessage" $parameterTypes $parameters  
} 
 
function GetConsoleWindow() 
{ 
    Invoke-Win32 "kernel32" ([IntPtr]) "GetConsoleWindow" 
} 
 
. Main 