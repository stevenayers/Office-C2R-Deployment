1. Create a Deployment Admin Service Account with Domain Admin
2. Create Share (e.g \\Dev-2k12-dc01\Deployment) and give the Deployment Admin full control, then paste all the contents from the zip into the share.
3. Run DeploymentSetup.ps1
4. Enter the Share Name, then click "submit"
5. Click on "Enter Admin Credentials" and enter the credentials
6. Make Shortcut targeting Upgrade.ps1 with the start in location as the script directory, push out via GPO.
Whatever name you choose for your shortcut, update it in config\Shortcutname.txt as this is what is used to specify what shortcut to delete! If the shortcut was "Deploy Office 2013.lnk", you would simply write in Deploy Office 2013

Set the following as the target Target:
Powershell.exe -executionpolicy bypass [ENTER SHARE PATH HERE]\Upgrade.ps1
7. If you want to amend who people should contact, edit the file PleaseContact.txt

NOTE: If you mess up entering the share name, make sure you go to Office365\config.xml and config\deploymentshare.txt and replace contents with office365\defaultconfig.xml and config\defaultdeploymentshare.txt